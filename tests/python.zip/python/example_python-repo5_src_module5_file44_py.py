"""
example/python-repo5 - src/module5/file44.py
Language: Python
Blob ID: pyt_000044_0005
Stars: 54
License: BSD-3-Clause
"""

def hello_world():
    """Sample function from example/python-repo5"""
    message = "Hello from example/python-repo5"
    print(message)
    return message

if __name__ == "__main__":
    hello_world()
