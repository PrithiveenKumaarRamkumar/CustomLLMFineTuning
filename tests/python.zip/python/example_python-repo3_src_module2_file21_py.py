"""
example/python-repo3 - src/module2/file21.py
Language: Python
Blob ID: pyt_000021_0003
Stars: 31
License: MIT
"""

def hello_world():
    """Sample function from example/python-repo3"""
    message = "Hello from example/python-repo3"
    print(message)
    return message

if __name__ == "__main__":
    hello_world()
