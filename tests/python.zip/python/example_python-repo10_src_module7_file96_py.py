"""
example/python-repo10 - src/module7/file96.py
Language: Python
Blob ID: pyt_000096_0010
Stars: 106
License: MIT
"""

def hello_world():
    """Sample function from example/python-repo10"""
    message = "Hello from example/python-repo10"
    print(message)
    return message

if __name__ == "__main__":
    hello_world()
