"""
example/python-repo2 - src/module6/file15.py
Language: Python
Blob ID: pyt_000015_0002
Stars: 25
License: MIT
"""

def hello_world():
    """Sample function from example/python-repo2"""
    message = "Hello from example/python-repo2"
    print(message)
    return message

if __name__ == "__main__":
    hello_world()
