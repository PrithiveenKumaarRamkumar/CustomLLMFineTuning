"""
example/python-repo3 - src/module6/file25.py
Language: Python
Blob ID: pyt_000025_0003
Stars: 35
License: Apache-2.0
"""

def hello_world():
    """Sample function from example/python-repo3"""
    message = "Hello from example/python-repo3"
    print(message)
    return message

if __name__ == "__main__":
    hello_world()
