"""
example/python-repo2 - src/module7/file16.py
Language: Python
Blob ID: pyt_000016_0002
Stars: 26
License: Apache-2.0
"""

def hello_world():
    """Sample function from example/python-repo2"""
    message = "Hello from example/python-repo2"
    print(message)
    return message

if __name__ == "__main__":
    hello_world()
