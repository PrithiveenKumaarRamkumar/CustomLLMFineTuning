"""
example/python-repo1 - src/module7/file6.py
Language: Python
Blob ID: pyt_000006_0001
Stars: 16
License: MIT
"""

def hello_world():
    """Sample function from example/python-repo1"""
    message = "Hello from example/python-repo1"
    print(message)
    return message

if __name__ == "__main__":
    hello_world()
