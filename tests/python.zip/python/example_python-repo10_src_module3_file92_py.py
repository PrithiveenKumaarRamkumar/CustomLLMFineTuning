"""
example/python-repo10 - src/module3/file92.py
Language: Python
Blob ID: pyt_000092_0010
Stars: 102
License: BSD-3-Clause
"""

def hello_world():
    """Sample function from example/python-repo10"""
    message = "Hello from example/python-repo10"
    print(message)
    return message

if __name__ == "__main__":
    hello_world()
