"""
example/python-repo3 - src/module1/file20.py
Language: Python
Blob ID: pyt_000020_0003
Stars: 30
License: BSD-3-Clause
"""

def hello_world():
    """Sample function from example/python-repo3"""
    message = "Hello from example/python-repo3"
    print(message)
    return message

if __name__ == "__main__":
    hello_world()
