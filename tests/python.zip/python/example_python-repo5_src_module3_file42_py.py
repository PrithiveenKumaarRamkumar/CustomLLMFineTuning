"""
example/python-repo5 - src/module3/file42.py
Language: Python
Blob ID: pyt_000042_0005
Stars: 52
License: MIT
"""

def hello_world():
    """Sample function from example/python-repo5"""
    message = "Hello from example/python-repo5"
    print(message)
    return message

if __name__ == "__main__":
    hello_world()
