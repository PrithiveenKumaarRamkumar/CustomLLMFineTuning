"""
example/python-repo5 - src/module9/file48.py
Language: Python
Blob ID: pyt_000048_0005
Stars: 58
License: MIT
"""

def hello_world():
    """Sample function from example/python-repo5"""
    message = "Hello from example/python-repo5"
    print(message)
    return message

if __name__ == "__main__":
    hello_world()
