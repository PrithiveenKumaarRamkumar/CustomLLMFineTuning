"""
example/python-repo7 - src/module3/file62.py
Language: Python
Blob ID: pyt_000062_0007
Stars: 72
License: BSD-3-Clause
"""

def hello_world():
    """Sample function from example/python-repo7"""
    message = "Hello from example/python-repo7"
    print(message)
    return message

if __name__ == "__main__":
    hello_world()
