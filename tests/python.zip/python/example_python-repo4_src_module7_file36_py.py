"""
example/python-repo4 - src/module7/file36.py
Language: Python
Blob ID: pyt_000036_0004
Stars: 46
License: MIT
"""

def hello_world():
    """Sample function from example/python-repo4"""
    message = "Hello from example/python-repo4"
    print(message)
    return message

if __name__ == "__main__":
    hello_world()
