"""
example/python-repo5 - src/module2/file41.py
Language: Python
Blob ID: pyt_000041_0005
Stars: 51
License: BSD-3-Clause
"""

def hello_world():
    """Sample function from example/python-repo5"""
    message = "Hello from example/python-repo5"
    print(message)
    return message

if __name__ == "__main__":
    hello_world()
