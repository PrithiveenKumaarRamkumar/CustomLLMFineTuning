"""
example/python-repo10 - src/module8/file97.py
Language: Python
Blob ID: pyt_000097_0010
Stars: 107
License: Apache-2.0
"""

def hello_world():
    """Sample function from example/python-repo10"""
    message = "Hello from example/python-repo10"
    print(message)
    return message

if __name__ == "__main__":
    hello_world()
