"""
example/python-repo1 - src/module9/file8.py
Language: Python
Blob ID: pyt_000008_0001
Stars: 18
License: BSD-3-Clause
"""

def hello_world():
    """Sample function from example/python-repo1"""
    message = "Hello from example/python-repo1"
    print(message)
    return message

if __name__ == "__main__":
    hello_world()
