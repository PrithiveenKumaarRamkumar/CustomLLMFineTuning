def hello_world():
    print("Hello, World!")
    return "success"

if __name__ == "__main__":
    hello_world()