"""
example/python-repo9 - src/module4/file83.py
Language: Python
Blob ID: pyt_000083_0009
Stars: 93
License: BSD-3-Clause
"""

def hello_world():
    """Sample function from example/python-repo9"""
    message = "Hello from example/python-repo9"
    print(message)
    return message

if __name__ == "__main__":
    hello_world()
