"""
example/python-repo3 - src/module7/file26.py
Language: Python
Blob ID: pyt_000026_0003
Stars: 36
License: BSD-3-Clause
"""

def hello_world():
    """Sample function from example/python-repo3"""
    message = "Hello from example/python-repo3"
    print(message)
    return message

if __name__ == "__main__":
    hello_world()
