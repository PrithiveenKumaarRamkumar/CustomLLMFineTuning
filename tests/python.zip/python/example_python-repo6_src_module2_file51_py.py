"""
example/python-repo6 - src/module2/file51.py
Language: Python
Blob ID: pyt_000051_0006
Stars: 61
License: MIT
"""

def hello_world():
    """Sample function from example/python-repo6"""
    message = "Hello from example/python-repo6"
    print(message)
    return message

if __name__ == "__main__":
    hello_world()
