"""
example/python-repo10 - src/module6/file95.py
Language: Python
Blob ID: pyt_000095_0010
Stars: 105
License: BSD-3-Clause
"""

def hello_world():
    """Sample function from example/python-repo10"""
    message = "Hello from example/python-repo10"
    print(message)
    return message

if __name__ == "__main__":
    hello_world()
