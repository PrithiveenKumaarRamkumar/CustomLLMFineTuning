"""
example/python-repo4 - src/module1/file30.py
Language: Python
Blob ID: pyt_000030_0004
Stars: 40
License: MIT
"""

def hello_world():
    """Sample function from example/python-repo4"""
    message = "Hello from example/python-repo4"
    print(message)
    return message

if __name__ == "__main__":
    hello_world()
