"""
example/python-repo1 - src/module4/file3.py
Language: Python
Blob ID: pyt_000003_0001
Stars: 13
License: MIT
"""

def hello_world():
    """Sample function from example/python-repo1"""
    message = "Hello from example/python-repo1"
    print(message)
    return message

if __name__ == "__main__":
    hello_world()
