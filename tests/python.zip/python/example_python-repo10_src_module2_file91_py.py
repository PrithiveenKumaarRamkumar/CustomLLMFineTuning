"""
example/python-repo10 - src/module2/file91.py
Language: Python
Blob ID: pyt_000091_0010
Stars: 101
License: Apache-2.0
"""

def hello_world():
    """Sample function from example/python-repo10"""
    message = "Hello from example/python-repo10"
    print(message)
    return message

if __name__ == "__main__":
    hello_world()
