"""
example/python-repo3 - src/module4/file23.py
Language: Python
Blob ID: pyt_000023_0003
Stars: 33
License: BSD-3-Clause
"""

def hello_world():
    """Sample function from example/python-repo3"""
    message = "Hello from example/python-repo3"
    print(message)
    return message

if __name__ == "__main__":
    hello_world()
