"""
example/python-repo4 - src/module4/file33.py
Language: Python
Blob ID: pyt_000033_0004
Stars: 43
License: MIT
"""

def hello_world():
    """Sample function from example/python-repo4"""
    message = "Hello from example/python-repo4"
    print(message)
    return message

if __name__ == "__main__":
    hello_world()
