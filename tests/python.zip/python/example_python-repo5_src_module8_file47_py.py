"""
example/python-repo5 - src/module8/file47.py
Language: Python
Blob ID: pyt_000047_0005
Stars: 57
License: BSD-3-Clause
"""

def hello_world():
    """Sample function from example/python-repo5"""
    message = "Hello from example/python-repo5"
    print(message)
    return message

if __name__ == "__main__":
    hello_world()
