"""
example/python-repo11 - src/module1/file100.py
Language: Python
Blob ID: pyt_000100_0011
Stars: 110
License: Apache-2.0
"""

def hello_world():
    """Sample function from example/python-repo11"""
    message = "Hello from example/python-repo11"
    print(message)
    return message

if __name__ == "__main__":
    hello_world()
