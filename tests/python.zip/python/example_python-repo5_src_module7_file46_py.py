"""
example/python-repo5 - src/module7/file46.py
Language: Python
Blob ID: pyt_000046_0005
Stars: 56
License: Apache-2.0
"""

def hello_world():
    """Sample function from example/python-repo5"""
    message = "Hello from example/python-repo5"
    print(message)
    return message

if __name__ == "__main__":
    hello_world()
