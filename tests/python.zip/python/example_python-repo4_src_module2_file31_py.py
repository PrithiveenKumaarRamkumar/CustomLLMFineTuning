"""
example/python-repo4 - src/module2/file31.py
Language: Python
Blob ID: pyt_000031_0004
Stars: 41
License: Apache-2.0
"""

def hello_world():
    """Sample function from example/python-repo4"""
    message = "Hello from example/python-repo4"
    print(message)
    return message

if __name__ == "__main__":
    hello_world()
