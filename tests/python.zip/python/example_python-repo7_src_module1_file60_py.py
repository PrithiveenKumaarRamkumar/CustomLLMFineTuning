"""
example/python-repo7 - src/module1/file60.py
Language: Python
Blob ID: pyt_000060_0007
Stars: 70
License: MIT
"""

def hello_world():
    """Sample function from example/python-repo7"""
    message = "Hello from example/python-repo7"
    print(message)
    return message

if __name__ == "__main__":
    hello_world()
