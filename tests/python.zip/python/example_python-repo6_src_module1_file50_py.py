"""
example/python-repo6 - src/module1/file50.py
Language: Python
Blob ID: pyt_000050_0006
Stars: 60
License: BSD-3-Clause
"""

def hello_world():
    """Sample function from example/python-repo6"""
    message = "Hello from example/python-repo6"
    print(message)
    return message

if __name__ == "__main__":
    hello_world()
