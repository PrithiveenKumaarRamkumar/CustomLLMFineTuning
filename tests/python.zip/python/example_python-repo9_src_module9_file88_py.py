"""
example/python-repo9 - src/module9/file88.py
Language: Python
Blob ID: pyt_000088_0009
Stars: 98
License: Apache-2.0
"""

def hello_world():
    """Sample function from example/python-repo9"""
    message = "Hello from example/python-repo9"
    print(message)
    return message

if __name__ == "__main__":
    hello_world()
