"""
example/python-repo10 - src/module10/file99.py
Language: Python
Blob ID: pyt_000099_0010
Stars: 109
License: MIT
"""

def hello_world():
    """Sample function from example/python-repo10"""
    message = "Hello from example/python-repo10"
    print(message)
    return message

if __name__ == "__main__":
    hello_world()
