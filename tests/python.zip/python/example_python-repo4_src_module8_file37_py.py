"""
example/python-repo4 - src/module8/file37.py
Language: Python
Blob ID: pyt_000037_0004
Stars: 47
License: Apache-2.0
"""

def hello_world():
    """Sample function from example/python-repo4"""
    message = "Hello from example/python-repo4"
    print(message)
    return message

if __name__ == "__main__":
    hello_world()
