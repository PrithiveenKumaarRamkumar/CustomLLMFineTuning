"""
example/python-repo4 - src/module3/file32.py
Language: Python
Blob ID: pyt_000032_0004
Stars: 42
License: BSD-3-Clause
"""

def hello_world():
    """Sample function from example/python-repo4"""
    message = "Hello from example/python-repo4"
    print(message)
    return message

if __name__ == "__main__":
    hello_world()
